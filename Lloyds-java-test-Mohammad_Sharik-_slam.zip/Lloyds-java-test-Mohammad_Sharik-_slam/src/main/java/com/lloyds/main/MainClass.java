package com.lloyds.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.lloyds.request.BookingRequest;
import com.lloyds.response.BookingResponse;


public class MainClass {

	public static void main(String[] args) {
		// Given input  taken as hard coded String
		String givenInput = "0950 1730\n"
				+ "2016-02-18 10:17:06 EMP001\n"
				+ "2016-02-21 09:00 12\n"
				+ "2016-02-18 10:17:06 EMP002\n"
				+ "2016-02-21 09:00 12\n"
				+ "2016-02-18 09:28:23 EMP003\n"
				+ "2016-02-22 14:00 2\n"
				+ "2016-02-18 11:23:45 EMP004\n"
				+ "2016-02-22 16:00 1\n"
				+ "2016-02-15 17:29:12 EMP005\n"
				+ "2016-02-21 16:00 3";
		
		String[] inputArray = givenInput.split("\n");
		
		String[] officeHour = inputArray[0].split(" ");
		if(isOfficeHours(officeHour[0], officeHour[1])) {
			
		
		
		List<BookingRequest> bookingReqList = new ArrayList<BookingRequest>();

		BookingRequest bookingReq = null;
		
		for(int item =1 ; item<inputArray.length; item++) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.ENGLISH);
			
			if(item % 2 != 0) {  // Odd Lines contain request submission date and empId
				bookingReq = new BookingRequest();
				String[] oddRow = inputArray[item].split(" ");
				try {
					Date date = formatter.parse(oddRow[0] + " "+oddRow[1]); 
					bookingReq.setReqSubmissionDateTime(date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				bookingReq.setEmpId(oddRow[2]);
				
			}else {         // Even lines contain meeting start time and duration
				
				String[] evenRow = inputArray[item].split(" ");
								
				bookingReq.setBookingDate(evenRow[0]);
				bookingReq.setMeetingStratTime(evenRow[1]);
				
				String[] meetingStartTime = evenRow[1].split(":");

				String[] durationInFraction;
				if(evenRow[2].contains(".")) { // if meeting duration in fraction
					durationInFraction = evenRow[2].split(".");
					int meetingEndTime = Integer.parseInt(meetingStartTime[0])+Integer.parseInt(durationInFraction[0]);
					int meetingEndTimeFraction = Integer.parseInt(meetingStartTime[1])+Integer.parseInt(durationInFraction[1]);
					bookingReq.setMeetingEndTime(""+meetingEndTime+":"+meetingEndTimeFraction);
				} else {
					int meetingEndTime = Integer.parseInt(meetingStartTime[0])+Integer.parseInt(evenRow[2]);
					bookingReq.setMeetingEndTime(""+meetingEndTime+":"+meetingStartTime[1]);
				}
				
				
				try {
					Date date = formatter.parse(evenRow[0] + " "+evenRow[1]);
					bookingReq.setMeetingStartDate(date);
					Calendar calendar = Calendar.getInstance();
				    calendar.setTime(date);
				    calendar.add(Calendar.HOUR_OF_DAY, Integer.parseInt(evenRow[2]));
				    bookingReq.setEndMeetingDateTime(calendar.getTime());
				} catch (ParseException e) {
					e.printStackTrace();
				}
				bookingReqList.add(bookingReq);
			}
		
		}
		
		// unique request submission time and ordered by submission date
		List<BookingRequest> distinctReqOrderByReqDate = bookingReqList.stream().distinct().sorted(Comparator.comparing(BookingRequest :: getReqSubmissionDateTime)).collect(Collectors.toList());

		List<BookingResponse>	bookingRes = buildBookingResponse(new ArrayList<BookingRequest>(), distinctReqOrderByReqDate);
		
		groupResByBookingDate(bookingRes);
		
		} else {
			System.out.println("Request is not in office hour");
		}
	   
	   
	}
	
	
	
	/**
	 * This method is for building booking response 
	 * @param bookingRes
	 * @param bookingReq
	 */
	private static void addInBookingResponse(List<BookingResponse> bookingRes, BookingRequest bookingReq) {
		BookingResponse bres = new BookingResponse();
		bres.setBookingDate(bookingReq.getBookingDate());
		bres.setEmpId(bookingReq.getEmpId());
		bres.setMeetingStartTime(bookingReq.getMeetingStratTime());
		bres.setMeetingEndTime(bookingReq.getMeetingEndTime());
		bookingRes.add(bres);
	}
	
	/**
	 * This method is for validating office hours
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	private static boolean isOfficeHours(String startTime, String endTime) {
		int intSartTime = Integer.parseInt(startTime);
		int intEndTime = Integer.parseInt(endTime);
		
		if(intSartTime < 900 || intEndTime > 1800) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * This method is for building filtered booking response 
	 * @param finalList
	 * @param distinctReqOrderByReqDate
	 * @return
	 */
	private static List<BookingResponse> buildBookingResponse(List<BookingRequest> finalList, List<BookingRequest> distinctReqOrderByReqDate) {
		List<BookingResponse> bookingRes = new ArrayList<BookingResponse>();
		
        for(BookingRequest bookReq : distinctReqOrderByReqDate) {
			
			if(finalList.isEmpty()) {
				finalList.add(bookReq);
				addInBookingResponse(bookingRes, bookReq);
				
			} else { // Filter to removed overlapped request
				Boolean isOverLLap = finalList.stream().anyMatch(
						f -> (bookReq.getMeetingStartDate().before(f.getMeetingStartDate()) && bookReq.getEndMeetingDateTime().after(f.getEndMeetingDateTime())
						 || (bookReq.getMeetingStartDate().after(f.getMeetingStartDate()) && bookReq.getMeetingStartDate().before(f.getEndMeetingDateTime()))
						 || (bookReq.getEndMeetingDateTime().after(f.getMeetingStartDate()) && bookReq.getEndMeetingDateTime().before(f.getEndMeetingDateTime()))
					));
				if(!isOverLLap) {
					finalList.add(bookReq);
					addInBookingResponse(bookingRes, bookReq);
				}
			}
		}
      return bookingRes;
	}
	
	/**
	 * This method is for grouping response by booking date
	 * @param bookingRes
	 */
	private static void groupResByBookingDate(List<BookingResponse> bookingRes) {
		 // Grouping request by booking date
		   Map<String, List<BookingResponse>> groupedResponse =   bookingRes.stream().collect(Collectors.groupingBy(BookingResponse :: getBookingDate));
		   
		   Iterator<Entry<String, List<BookingResponse>>> entry = groupedResponse.entrySet().iterator();
		   while(entry.hasNext()) {
			   Map.Entry<String, List<BookingResponse>> mapEntry = entry.next();
			   System.out.println(mapEntry.getKey());
			   List<BookingResponse> bor = mapEntry.getValue();
			   bor.forEach(res -> {
				   System.out.print(res.getMeetingStartTime()+ " "+res.getMeetingEndTime()+ " "+res.getEmpId());
				   System.out.println();
			   });
		      
		   }
	}
	

}


