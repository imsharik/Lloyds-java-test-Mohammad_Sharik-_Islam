package com.lloyds.request;

import java.util.Date;

public class BookingRequest {
	
	
	private Date reqSubmissionDateTime; 
	private String empId;      
	private Date meetingStartDate;
	private String meetingStratTime;
	private String meetingEndTime;
	private Date endMeetingDateTime;
	private String bookingDate; 
	

	public Date getReqSubmissionDateTime() {
		return reqSubmissionDateTime;
	}
	public void setReqSubmissionDateTime(Date reqSubmissionDateTime) {
		this.reqSubmissionDateTime = reqSubmissionDateTime;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	public Date getMeetingStartDate() {
		return meetingStartDate;
	}
	public void setMeetingStartDate(Date meetingStartDate) {
		this.meetingStartDate = meetingStartDate;
	}
	public String getMeetingStratTime() {
		return meetingStratTime;
	}
	public void setMeetingStratTime(String meetingStratTime) {
		this.meetingStratTime = meetingStratTime;
	}
	public String getMeetingEndTime() {
		return meetingEndTime;
	}
	public void setMeetingEndTime(String meetingEndTime) {
		this.meetingEndTime = meetingEndTime;
	}
	public Date getEndMeetingDateTime() {
		return endMeetingDateTime;
	}
	public void setEndMeetingDateTime(Date endMeetingDateTime) {
		this.endMeetingDateTime = endMeetingDateTime;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((reqSubmissionDateTime == null) ? 0 : reqSubmissionDateTime.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingRequest other = (BookingRequest) obj;
		if (reqSubmissionDateTime == null) {
			if (other.reqSubmissionDateTime != null)
				return false;
		} else if (!reqSubmissionDateTime.equals(other.reqSubmissionDateTime))
			return false;
		return true;
	}
	
	
	
	
	
}
