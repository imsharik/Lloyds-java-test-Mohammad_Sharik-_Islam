package com.lloyds.response;

public class BookingResponse {

	private String bookingDate;
	private String meetingStartTime;
	private String meetingEndTime;
	private String empId;
	
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getMeetingStartTime() {
		return meetingStartTime;
	}
	public void setMeetingStartTime(String meetingStartTime) {
		this.meetingStartTime = meetingStartTime;
	}
	public String getMeetingEndTime() {
		return meetingEndTime;
	}
	public void setMeetingEndTime(String meetingEndTime) {
		this.meetingEndTime = meetingEndTime;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	@Override
	public String toString() {
		return "BookingResponse [meetingStartTime=" + meetingStartTime + ", meetingEndTime=" + meetingEndTime
				+ ", empId=" + empId + "]";
	}
	
	
}
