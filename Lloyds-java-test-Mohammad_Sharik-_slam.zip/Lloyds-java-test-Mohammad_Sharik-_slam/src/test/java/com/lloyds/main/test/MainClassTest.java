package com.lloyds.main.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.lloyds.main.MainClass;
import com.lloyds.request.BookingRequest;
import com.lloyds.response.BookingResponse;


public class MainClassTest {

	@Test
	public void isOfficeHours_True_Test() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method method = Whitebox.getMethod(MainClass.class, "isOfficeHours", String.class, String.class);
		boolean isOfficeHour = (Boolean)method.invoke(null, "950", "1600");
		assertTrue(isOfficeHour);
		
	}
	
	@Test
	public void isOfficeHours_Fail_Test() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Method method = Whitebox.getMethod(MainClass.class, "isOfficeHours", String.class, String.class);
		boolean isOfficeHour = (Boolean)method.invoke(null, "850", "1600");
		assertFalse(isOfficeHour);
		
	}
	
	@Test
	public void addInBookingResponseTest() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		List<BookingResponse> bookingRes = new ArrayList<>();
		BookingRequest bookingReq = new BookingRequest();
		bookingReq.setEmpId("1234");
		bookingReq.setBookingDate("1991-02-02");
		bookingReq.setMeetingStratTime("9:00");
		bookingReq.setMeetingEndTime("11:00");
		Method method = Whitebox.getMethod(MainClass.class, "addInBookingResponse", List.class, BookingRequest.class);
		method.invoke(null, bookingRes, bookingReq);
		assertFalse(bookingRes.isEmpty());
	}

	@Test
	public void buildBookingResponse_MeetingOverlapTest() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		List<BookingRequest> finalList = new ArrayList<>();
		List<BookingRequest> distinctReqOrderByReqDate = new ArrayList<>();
		BookingRequest br = new BookingRequest();
		br.setMeetingStartDate(new Date(2006, 02, 02, 10, 0));
		br.setEndMeetingDateTime(new Date(2006, 02, 02, 12, 0));
		BookingRequest br2 = new BookingRequest();
		br2.setMeetingStartDate(new Date(2006, 02, 02, 8, 0));
		br2.setEndMeetingDateTime(new Date(2006, 02, 02, 11, 0));
		distinctReqOrderByReqDate.add(br);
		distinctReqOrderByReqDate.add(br2);
		Method method = Whitebox.getMethod(MainClass.class, "buildBookingResponse", List.class, List.class);
		List<BookingResponse> bRes =   (List<BookingResponse>)method.invoke(null, finalList, distinctReqOrderByReqDate);
		assertTrue(bRes.size() == 1);
	}
}
